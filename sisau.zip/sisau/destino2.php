<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
	$id = $_SESSION['id'];
  	if ($logado == '2')
	{		
		echo'<html>
		<head>
		<title>Alterar Dados</title>
		</head>
		<body>';
		//recebendo vari�vel
		//retirando as oespa�os e aspas
		$uf = str_replace(" ", "%", $HTTP_POST_VARS[uf]); 
		
		$nome = $HTTP_POST_VARS[nome];
		$numero = $HTTP_POST_VARS[numero];
		$rua = $HTTP_POST_VARS[rua];
		$complemento = $HTTP_POST_VARS[complemento];
		$bairro = $HTTP_POST_VARS[bairro];
		$cidade = $HTTP_POST_VARS[cidade];
		$tel1 = $HTTP_POST_VARS[tel1];
		$tel2 = $HTTP_POST_VARS[tel2];
		$diasaida = $HTTP_POST_VARS[diasaida];
		$messaida = $HTTP_POST_VARS[messaida];
		$anosaida = $HTTP_POST_VARS[anosaida];
		$diaretorno = $HTTP_POST_VARS[diaretorno];
		$mesretorno = $HTTP_POST_VARS[mesretorno];
		$anoretorno = $HTTP_POST_VARS[anoretorno];	
		
		//formatando data
		$datasaida = "".$HTTP_POST_VARS['anosaida']."-".$_POST['messaida']."-".$_POST['diasaida']."";
		$dataretorno = "".$HTTP_POST_VARS['anoretorno']."-".$_POST['mesretorno']."-".$_POST['diaretorno']."";
		//inserindo no banco		
		$result = mysql_query("UPDATE destino SET rua='". $rua ."', numero='". $numero ."',complemento='". $complemento ."',bairro='". $bairro ."',cidade='". $cidade ."',tel1='". $tel1 ."',tel2='". $tel2 ."' ,uf='". $uf ."',diasaida='". $diasaida ."',messaida='". $messaida ."',anosaida='". $anosaida ."',diaretorno='". $diaretorno ."',mesretorno='". $mesretorno ."',anoretorno='". $anoretorno ."', datasaida='".$datasaida."', dataretorno='".$dataretorno."' WHERE id='".$id."';",$conexao);
       
		if ($result)
			{
			echo '<center>Destino Registrado com Sucesso.<br><center>Boa Viagem!<br><br><center>Mantenha seu Cadastro Atualizado.';
			}
		else
			{
				echo '<center> Erro ao Registrar Destino! contate o administrador!';
			}
	
		}
			else
				{
					echo '<center>Usuario n�o autorizado!';
				}
		}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>

</body>
</body>
</html>
