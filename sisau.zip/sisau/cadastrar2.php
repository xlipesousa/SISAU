<?
include "base.php";

		$nome = $_POST["nome"];
		$su = $_POST["su"];
		$usuario = $_POST["login"];
		$senha = $_POST["senha"];
		
		$result = mysql_query('insert into usuarios (nome,su,usuario,senha) values("'.$nome.'","'.$su.'","'.$usuario.'","'.$senha.'");',$conexao);
		if ($result)
			{
			$result2 = mysql_query('insert into cadastro (usuario,su) values("'.$usuario.'","'.$su.'");',$conexao);   	   
			$result3 = mysql_query('insert into destino (usuario) values("'.$usuario.'");',$conexao);   	   

			echo '
				<html>
					<head>
						<title>Cadastrar</title>
						</head>
						<body>
							<center>Cadastro efetuado com Sucesso!
							<br>Efetue seu Login para continuar.
							<br><br>
							Obs: Atualize seu endere�o FIXO no link cadastro.
						</body>
				</html>';
			}
		else
			{	echo '
				<html>
					<head>
					<title>Cadastrar</title>
					</head>
					<body>
			 			<center>Erro ao Cadastrar! <br> Nome de usu�rio j� existente.<br>
						<a href="cadastrar.php" target="Display">VOLTAR</a>
					</body>
				</html>';
			}
		
?>
