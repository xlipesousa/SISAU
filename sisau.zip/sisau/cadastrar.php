<?
include "base.php";
echo'
<htm>
<head>
<title>Cadastrar</title>
</head>
<body>
<div align="center">
  <p>Cadastro</p>
</div>
<div align="center">
 <form action="cadastrar2.php" method="post" enctype="multipart/form-data" target="Display" name="cadastrar">
  <div align="center">
    <table width="512" border="0"> 
      <tr>
        <td>Nome de Guerra:</td>
        <td><label>
          <input name="nome" type="text" size="30"> Ex: Sgt Max Wolff
        </label></td>
      </tr>
	  <tr>
        <td>Subunidade:</td>
        <td><label>
        <select name="su">
          <option value="0">Selecione</option>
          <option value="1bo">1� BO</option>
          <option value="2bo">2� BO</option>
          <option value="bc">BC</option>
          <option value="aae">AAe</option>
        </select>
        </label></td>
      </tr>
      <tr>
        <td>Login:</td>
        <td><label>
          <input type="text" name="login">
        </label></td>
      </tr>
	  <tr>
        <td width="113">Senha:</td>
        <td width="389"><label>
          <input type="password" name="senha">
        </label></td>
      </tr>
    </table>
    <p>
      <label>
      <input type="submit" name="Submit" value="Salvar">
      </label>
    </p>
  </div>
</form>
</body>
</html>';

?>
