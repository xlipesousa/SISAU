-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 18/02/2020 às 15:07:17
-- Versão do Servidor: 5.5.41-0+wheezy1
-- Versão do PHP: 5.3.3-7+squeeze19

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `sisau2`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastro`
--

CREATE TABLE IF NOT EXISTS `cadastro` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `rua` char(60) DEFAULT NULL,
  `numero` char(6) DEFAULT NULL,
  `complemento` char(15) DEFAULT '-',
  `bairro` char(30) DEFAULT NULL,
  `cidade` char(30) DEFAULT NULL,
  `uf` char(2) DEFAULT NULL,
  `tel1` char(12) DEFAULT NULL,
  `tel2` char(12) DEFAULT NULL,
  `usuario` char(30) NOT NULL,
  `su` char(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `cadastro`
--

INSERT INTO `cadastro` (`id`, `rua`, `numero`, `complemento`, `bairro`, `cidade`, `uf`, `tel1`, `tel2`, `usuario`, `su`) VALUES
(1, NULL, NULL, '-', NULL, NULL, NULL, NULL, NULL, 'admin', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `destino`
--

CREATE TABLE IF NOT EXISTS `destino` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `rua` char(60) DEFAULT NULL,
  `numero` char(6) DEFAULT NULL,
  `complemento` char(15) DEFAULT '-',
  `bairro` char(30) DEFAULT NULL,
  `cidade` char(30) DEFAULT NULL,
  `uf` char(2) DEFAULT NULL,
  `tel1` char(12) DEFAULT NULL,
  `tel2` char(12) DEFAULT NULL,
  `diasaida` char(2) DEFAULT NULL,
  `messaida` char(2) DEFAULT NULL,
  `anosaida` char(4) DEFAULT NULL,
  `diaretorno` char(2) DEFAULT NULL,
  `mesretorno` char(2) DEFAULT NULL,
  `anoretorno` char(4) DEFAULT NULL,
  `usuario` char(30) NOT NULL,
  `datasaida` date DEFAULT NULL,
  `dataretorno` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `destino`
--

INSERT INTO `destino` (`id`, `rua`, `numero`, `complemento`, `bairro`, `cidade`, `uf`, `tel1`, `tel2`, `diasaida`, `messaida`, `anosaida`, `diaretorno`, `mesretorno`, `anoretorno`, `usuario`, `datasaida`, `dataretorno`) VALUES
(1, NULL, NULL, '-', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'admin', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `nome` varchar(60) NOT NULL,
  `su` char(3) NOT NULL,
  `usuario` char(30) NOT NULL,
  `senha` varchar(30) NOT NULL,
  `nivel` enum('1','2','3') NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `su`, `usuario`, `senha`, `nivel`) VALUES
(1, 'Administrador', 'bc', 'admin', 'admin', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
