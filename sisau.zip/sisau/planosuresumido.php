<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
	$id = $_SESSION['id'];
  	if ($logado == '1')
	{		
		echo'<html>
		<head>
		<title>Plano de Chamada por SU</title>
		</head>
		<body>';
		$su = $HTTP_POST_VARS['su'];		
		//pesquisando no banco		
		$result = mysql_query("SELECT * FROM cadastro WHERE su = '".$su."' order by cidade desc;",$conexao);
       
		$Quantos = mysql_num_rows($result);
		if($Quantos > 0)
			{
			
				//cabe�alho
				//gerando data do relat�rio
				$data=date('d/m/Y');
				$hora=date('H');
				$minutos=date('i');
				$segundos=date('s');
				echo '<center>';
				if($hora>=12 && $hora<18)
				{
				echo("Gerado em: $data - $hora:$minutos:$segundos");
				}
				if($hora>=18 && $hora<24)
				{
				echo("Gerado em: $data - $hora:$minutos:$segundos");
				}
				if($hora>=24 && $hora<12)
				{
				echo("Gerado em: $data - $hora:$minutos:$segundos");
				}
				echo '</center><br>';
		
		
		       //t�rmino data relat�rio

				
        echo'<center>Plano de Chamada de Militares da ';
		echo $su;
		echo' Ordenados por Cidade ';

		echo '<br><br><center>Total de registros encontrados: ';
		echo $Quantos;		
				
				//formatando a tabela de destinos
				echo'
    <table width="524" border="1">
      
      <tr>
        <td width="200"><div align="center">Nome</div></td>
        <td width="118"><div align="center">Cidade</div></td>
		<td width="80"><div align="center">Bairro</div></td>
        <td width="70"><div align="center">Tel1</div></td>
        <td width="70"><div align="center">Tel2</div></td>
      </tr>
      <tr>';
//preenchendo a tabela	  
		$i=0;
			for ($i==0; $i<$Quantos; $i++)
						{
							$cidade = mysql_result($result,$i,cidade);
							$bairro = mysql_result($result,$i,bairro);
							$tel1 = mysql_result($result,$i,tel1);
							$tel2 = mysql_result($result,$i,tel2);
							$id = mysql_result($result,$i,id);
							echo '<td>';
							$consulta = mysql_query("SELECT nome FROM usuarios WHERE id like '".$id."';",$conexao);

							if (mysql_num_rows($consulta) > 0) {
								$nome = mysql_result($consulta,0,nome);
								if (isset($id) && (!isset($nome))) {
								}
							}
							echo $nome;
							echo'</td>';
							echo '<td>';
							echo $cidade;
							echo'</td>';
							echo '<td>';
							echo $bairro;
							echo'</td>';
							echo '<td>';
							echo $tel1;
							echo'</td>';
							echo '<td>';
							echo $tel2;
							echo'</td>
							
							</form>';
						echo '</td></tr>';
						}
			
			echo '</table>';
			}

				//fim da tabela de destinos
		else
			{
				echo '<center>Nenhum registro encontrado para este per�odo.';
			}
	
	}
	else
	{
		echo '<center>Usuario n�o autorizado!';
	}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>
</body>
</html>
