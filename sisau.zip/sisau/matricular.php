<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
  	if ($logado == '3')
		{
// Prepara a vari�vel caso o formul�rio tenha sido postado
$foto = isset($_FILES["foto"]) ? $_FILES["foto"] : FALSE;

$config = array();
// Tamano m�ximo da imagem, em bytes
$config["tamanho"] = 106883;
// Largura M�xima, em pixels
$config["largura"] = 350;
// Altura M�xima, em pixels
$config["altura"] = 250;
// Diret�rio onde a imagem ser� salva
$config["diretorio"] = "fotos/";

// Gera um nome para a imagem e verifica se j� n�o existe, caso exista, gera outro nome e assim sucessivamente..
// Fun��o Recursiva
function nome($extensao)
{
    global $config;

    // Gera um nome �nico para a imagem
    $temp = substr(md5(uniqid(time())), 0, 10);
    $imagem_nome = $temp . "." . $extensao;
    
    // Verifica se o arquivo j� existe, caso positivo, chama essa fun��o novamente
    if(file_exists($config["diretorio"] . $imagem_nome))
    {
        $imagem_nome = nome($extensao);
    }

    return $imagem_nome;
}

if($foto)
{
    $erro = array();
    
    // Verifica o mime-type do arquivo para ver se � de imagem.
    // Caso fosse verificar a extens�o do nome de arquivo, o c�digo deveria ser:
    //
    // if(!eregi("\.(jpg|jpeg|bmp|gif|png){1}$", $arquivo["name"])) {
    //      $erro[] = "Arquivo em formato inv�lido! A imagem deve ser jpg, jpeg, bmp, gif ou png. Envie outro arquivo"; }
    //
    // Mas, o que ocorre � que alguns usu�rios mal-intencionados, podem pegar um v�rus .exe e simplesmente mudar a extens�o
    // para alguma das imagens e enviar. Ent�o, n�o adiantaria em nada verificar a extens�o do nome do arquivo.
    if(!eregi("^image\/(pjpeg|jpeg|png|gif|bmp)$", $foto["type"]))
    {
        $erro[] = "Arquivo em formato inv�lido! A imagem deve ser jpg, jpeg, bmp, gif ou png. Envie outro arquivo";
    }
    else
    {
        // Verifica tamanho do arquivo
        if($foto["size"] > $config["tamanho"])
        {
            $erro[] = "Arquivo em tamanho muito grande! A imagem deve ser de no m�ximo " . $config["tamanho"] . " bytes. Envie outro arquivo";
        }
        
        // Para verificar as dimens�es da imagem
        $tamanhos = getimagesize($foto1["tmp_name"]);
        
        // Verifica largura
        if($tamanhos[0] > $config["largura"])
        {
            $erro[] = "Largura da imagem n�o deve ultrapassar " . $config["largura"] . " pixels";
        }

        // Verifica altura
        if($tamanhos[1] > $config["altura"])
        {
            $erro[] = "Altura da imagem n�o deve ultrapassar " . $config["altura"] . " pixels";
        }
    }

    if(!sizeof($erro))
    {
        // Pega extens�o do arquivo, o indice 1 do array conter� a extens�o
        preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $foto["name"], $ext);
        
        // Gera nome �nico para a imagem
        $imagem_nome = nome($ext[1]);

        // Caminho de onde a imagem ficar�
        $imagem_dir = $config["diretorio"] . $imagem_nome;
		
		//efetua cadastro na tabela alunos
		$result = mysql_query('insert into alunos (numero,ano,qm,nome,idt,ts,rh,foto) values("'.$numero.'","'.$ano.'","'.$qm.'","'.$nome.'","'.$idt.'","'.$ts.'","'.$rh.'","'.$imagem_dir.'");',$conexao);
		
		//inicia as notas de conceito com zero
		$notaconceito = mysql_query('insert into aaa (numero,b001,b002,b003,b004,b005,b006,b007,b008,b009,b010,obs) values("'.$numero.'","0","0","0","0","0","0","0","0","0","0","");',$conexao);
		
	   	//inicia as notas finais do curso e das provas com zero
		$notasfinais = mysql_query('insert into notas (numero,qm,comum,peculiar,nv,nf,conceito) values("'.$numero.'","'.$qm.'","0","0","0","0","0");',$conexao);
		
		
	    // Faz o upload da imagem
        move_uploaded_file($foto["tmp_name"], $imagem_dir);	

    }
}
echo '<html>
<head>
<title>Matricular</title>
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
.style2 {color: #FF0000}
-->
</style>
</head>

<body>

<center>';
// Imagem foi enviada com sucesso, mostra mensagem de SUCESSO
if($foto && !sizeof($erro))
{
    echo "<img src=\"" . $imagem_dir . "\" border=0><BR>";
	echo $nome;	
	echo"<BR>Aluno matriculado com sucesso!<br>
	<a href=\"matricular.php\">Nova matricula</a>";
}

// Ocorreu algum erro ou ainda o formul�rio n�o foi postado
else
{
?>

<div align="center">
  <p>Dados do Aluno </p>
</div>
<form action="<?echo $PHP_SELF?>" method="post" enctype="multipart/form-data">
  <div align="center">
    <table width="512" border="0">
      <tr>
        <td width="72">N&uacute;mero:</td>
        <td width="430"><label>
          <input type="text" name="numero">
        </label></td>
      </tr>
      <tr>
        <td>Ano:</td>
        <td><label>
          <select name="ano">
            <option value="0">Selecione</option>
            <option value="2005">2005</option>
            <option value="2006">2006</option>
            <option value="2007">2007</option>
            <option value="2008">2008</option>
          </select>
        </label></td>
      </tr>
      <tr>
        <td>QM:</td>
        <td><label>
          <select name="qm">
            <option value="0">Selecione</option>
            <option value="00-10">00-10 corneteiro</option>
            <option value="06-01">06-01 gu p&ccedil; obus</option>
            <option value="06-01">06-01 Remum</option>
            <option value="06-04">06-04 c tir</option>
            <option value="06-15">06-15 topo</option>
            <option value="08-33">08-33 atendente/padioleiro</option>
            <option value="09-45">09-45 aux mec arm leve</option>
            <option value="09-47">09-47 aux mec elt</option>
            <option value="09-51">09-51 aux mec auto</option>
            <option value="10-55">10-55 motorista</option>
            <option value="10-61">10-61 cozinheiro/aux cozinha</option>
            <option value="11-73">11-73 aux mec eqp elt</option>
            <option value="11-74">11-74 radioperador/telefonista</option>
          </select>
        </label></td>
      </tr>
      <tr>
        <td>Nome:</td>
        <td><label>
          <input name="nome" type="text" size="60"><BR>
		  <span class="style2">Cadastre o Nome com letras mai�sculas.</span>
        </label></td>
      </tr>
      <tr>
        <td>Identidade:</td>
        <td><label>
          <input type="text" name="idt">
        </label></td>
      </tr>
      <tr>
        <td>TS:</td>
        <td><label>
          <select name="ts">
            <option value="0">Selecione</option>
            <option value="a">A</option>
            <option value="b">B</option>
            <option value="ab">AB</option>
            <option value="o">O</option>
          </select>
        </label></td>
      </tr>
      <tr>
        <td>Fator RH: </td>
        <td><label>
          <select name="rh">
            <option value="0">Selecione</option>
            <option value="positivo">Positivo</option>
            <option value="negativo">Negativo</option>
          </select>
        </label></td>
      </tr>
      <tr>
        <td>Foto:</td>
        <td><label>
          <input name=foto type=file size=30>
        </label></td>
      </tr>
      <tr>
        <td colspan="2"><div align="center"><span class="style2">Obs: A foto deve estar no tamanho 95x127</span></div></td>
      </tr>
    </table>
    <p>
      <label>
      <input type="submit" name="Submit" value="Cadastrar">
      </label>
    </p>
  </div>
</form>
<p align="center">&nbsp;</p>

<? }
	}
	else
	{
	echo '<center>Usuario n�o autorizado!';
	}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}	
	 ?>
</body>
</html>