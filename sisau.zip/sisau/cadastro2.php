<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
	$id = $_SESSION['id'];
  	if ($logado == '2')
	{		
		echo'<html>
		<head>
		<title>Alterar Dados</title>
		</head>
		<body>';
		//recebendo vari�vel
		//retirando as oespa�os e aspas
		$uf = str_replace(" ", "%", $HTTP_POST_VARS[uf]); 
		
		$nome = $HTTP_POST_VARS[nome];
		$numero = $HTTP_POST_VARS[numero];
		$rua = $HTTP_POST_VARS[rua];
		$complemento = $HTTP_POST_VARS[complemento];
		$bairro = $HTTP_POST_VARS[bairro];
		$cidade = $HTTP_POST_VARS[cidade];
		$tel1 = $HTTP_POST_VARS[tel1];
		$tel2 = $HTTP_POST_VARS[tel2];
		$su = $HTTP_POST_VARS[su];
		
		//inserindo no banco		
		$result = mysql_query("UPDATE cadastro SET rua='". $rua ."', numero='". $numero ."',complemento='". $complemento ."',bairro='". $bairro ."',cidade='". $cidade ."',tel1='". $tel1 ."',tel2='". $tel2 ."' ,uf='". $uf ."', su='".$su."' WHERE id='".$id."';",$conexao);
		
		$resultnome = mysql_query("UPDATE usuarios SET nome='". $nome ."' WHERE id='".$id."';",$conexao);
       
		if (($result) and ($resultnome))
			{
			echo '<center>Cadastro Alterado com Sucesso!';
			}
		else
			{
				echo '<center> Erro ao alterar as cadastro! contate o administrador!';
			}
	
		}
			else
				{
					echo '<center>Usuario n�o autorizado!';
				}
		}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>

</body>
</body>
</html>
