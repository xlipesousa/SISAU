<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
  	if ($logado == '1')
	{
	echo'
	<center> Relat�rio</center><br>
<form name="form1" method="post" action="relatorio2.php">
  <table align="center" size="500" border="0">
  <tr>
  	<td>
  Data in�cio:
  	</td>
	<td>
    <input type="text" name="diasaida" size="4" maxlength="2" >
/ 
<input type="text" name="messaida" size="4"  maxlength="2">
/
<input type="text" name="anosaida" size="8" maxlength="4">
	</td>
	</tr>
    <tr>
		<td>
		Data t�rmino: 
  		</td>
		<td>
  <input type="text" name="diaretorno" size="4" >
/ 
<input type="text" name="mesretorno" size="4" >
/
<input type="text" name="anoretorno" size="8" >
</td>
</tr>
<tr>
	<td colspan ="2">
	  <p align="center">
		<label>
		<input type="submit" name="Submit" value="Pesquisar">
		</label>
	</p>
</td>
</tr>
</table>
</form>';

}
	else
		{
			echo '<center>Usuario n�o autorizado!';
		}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>
