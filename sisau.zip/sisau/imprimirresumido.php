<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
	$id = $_SESSION['id'];
  	if ($logado == '1')
	{		
		echo'<html>
		<head>
		<title>Relat�rio Resumido</title>
		</head>
		<body>';
				
		//formatando data
		$datasaida = "".$HTTP_POST_VARS['anosaida']."-".$_POST['messaida']."-".$_POST['diasaida']."";
		$dataretorno = "".$HTTP_POST_VARS['anoretorno']."-".$_POST['mesretorno']."-".$_POST['diaretorno']."";
		//inserindo no banco		
		$result = mysql_query("SELECT * FROM destino WHERE datasaida BETWEEN '".$datasaida."' AND '".$dataretorno."' order by datasaida desc;",$conexao);
       
		$Quantos = mysql_num_rows($result);
		if($Quantos > 0)
			{
				// formatando cabe�alho com data
				$diasaida = $HTTP_POST_VARS['diasaida'];
				$messaida = $HTTP_POST_VARS['messaida'];
				$anosaida = $HTTP_POST_VARS['anosaida'];
				$diaretorno = $HTTP_POST_VARS['diaretorno'];
				$mesretorno = $HTTP_POST_VARS['mesretorno'];
				$anoretorno = $HTTP_POST_VARS['anoretorno'];
				
				//cabe�alho
				
				//gerando data do relat�rio
				$data=date('d/m/Y');
				$hora=date('H');
				$minutos=date('i');
				$segundos=date('s');
				echo '<center>';
				if($hora>=12 && $hora<18)
				{
				echo("Gerado em: $data - $hora:$minutos:$segundos");
				}
				if($hora>=18 && $hora<24)
				{
				echo("Gerado em: $data - $hora:$minutos:$segundos");
				}
				if($hora>=24 && $hora<12)
				{
				echo("Gerado em: $data - $hora:$minutos:$segundos");
				}
				echo '</center><br>';
		
		
		       //t�rmino data relat�rio

				
        echo' <center>Militares que se ausentar�o da guarni��o no per�odo de: <br><center>';
		echo $diasaida;
		echo '/';
		echo $messaida;
		echo'/';
		echo $anosaida;
		echo' a ';
		echo $diaretorno;
		echo '/';
		echo $mesretorno;
		echo'/';
		echo $anoretorno;
		
		echo '<br><br><center>Total de registros encontrados: ';
		echo $Quantos;		
				
				//formatando a tabela de destinos
				echo'
    <table width="620" border="1">
      
      <tr>
        <td width="200"><div align="center">Nome</div></td>
        <td width="147"><div align="center">Cidade</div></td>
		<td width="8"><div align="center">UF</div></td>
        <td width="70"><div align="center">Partida</div></td>
        <td width="70"><div align="center">Retorno</div></td>
        <td width="150"><div align="center">Contato</div></td>

      </tr>
      <tr>';
//preenchendo a tabela	  
		$i=0;
			for ($i==0; $i<$Quantos; $i++)
						{
							$cidade = mysql_result($result,$i,cidade);
							$uf = mysql_result($result,$i,uf);
							$diasaida = mysql_result($result,$i,diasaida);
							$messaida = mysql_result($result,$i,messaida);
							$anosaida = mysql_result($result,$i,anosaida);
							$diaretorno = mysql_result($result,$i,diaretorno);
							$mesretorno = mysql_result($result,$i,mesretorno);
							$anoretorno = mysql_result($result,$i,anoretorno);
							$contato = mysql_result($result,$i,tel1);
							$id = mysql_result($result,$i,id);
							echo '<td>';
							$consulta = mysql_query("SELECT nome FROM usuarios WHERE id like '".$id."';",$conexao);
							$nome = mysql_result($consulta,0,nome);
							echo $nome;
							echo'</td>';
							echo '<td>';
							echo $cidade;
							echo'</td>';
							echo '<td>';
							echo $uf;
							echo'</td>';
							echo '<td>';
							echo $diasaida;
							echo '/';
							echo $messaida;
							echo '/';
							echo $anosaida;
							echo'</td>';
							echo '<td>';
							echo $diaretorno;
							echo '/';
							echo $mesretorno;
							echo '/';
							echo $anoretorno;
							echo'</td>';
							echo '<td>';
							echo $contato;
							echo'</td>
							</tr>';
						}
			
			echo '</table>';

			
			}

				//fim da tabela de destinos
		else
			{
				echo '<center>Nenhum registro encontrado para este per�odo.';
			}
	
	}
	else
	{
		echo '<center>Usuario n�o autorizado!';
	}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>
</body>
</html>
