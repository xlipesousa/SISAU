<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
  	if ($logado == '1')
	{
	echo'
	<center>Plano de Chamada</center><br>
<form name="form1" method="post" action="planochamadasu.php">
  <table size="500" border="0">
  <tr>
  	<td size="150">
		Por SU:
  	</td>
	<td size="150">
	 <select name="su">
          <option value="0">Selecione</option>
          <option value="1bo">1� BO</option>
          <option value="2bo">2� BO</option>
          <option value="bc">BC</option>
          <option value="aae">AAe</option>
        </select>
	</td>
	<td size="200">
		<input type="submit" value="Gerar">
	</td>
	</tr>
</table>
</form>
<form name="form2" method="post" action="planochamadacidade.php">
  <table size="500" border="0">
	<tr>
	<td size="150">
		Por Cidade:   
   	</td>
	<td size="150">
	<select name="cidade">
		<option value="">Selecione</option>
		<option value="Itu">Itu</option>
		<option value="Salto">Salto</option>
		<option value="Indaiatuba">Indaiatuba</option>
		<option value="Sorocaba">Sorocaba</option>
		<option value="Cabreuva">Cabreuva</option>
		<option value="Itapetininga">Itapetininga</option>
		<option value="Itupeva">Itupeva</option>
		<option value="Porto Feliz">Porto Feliz</option>
		<option value="Jundia�">Jundia�</option>
          </select>
	</td>
	<td size="200">
		<input type="submit" value="Gerar">
	</td>
</tr>
</table>
</form>';

}
	else
		{
			echo '<center>Usuario n�o autorizado!';
		}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>
