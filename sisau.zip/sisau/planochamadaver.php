<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
$logado = $_SESSION['nivel'];
	
?>
<html>
<head>
<title>Relat�rio de destinos</title>
</head>

<body>
<div align="center">
  
  <p></p>
  <?
  if($logado =='1')
  {
  $id = $HTTP_POST_VARS['id'];
  $nome = $HTTP_POST_VARS['nome'];
  
  //fazendo consulta de dados no banco
  $result = mysql_query("select * from cadastro where id = '".$id."';",$conexao);
  //armazenando resultado de pesquisa
  $rua = mysql_result($result,0,rua);
  $numero = mysql_result($result,0,numero);
  $complemento = mysql_result($result,0,complemento);
  $bairro = mysql_result($result,0,bairro);
  $cidade = mysql_result($result,0,cidade);
  $uf = mysql_result($result,0,uf);
  $tel1 = mysql_result($result,0,tel1);
  $tel2 = mysql_result($result,0,tel2);
  $su = mysql_result($result,0,su);
  
  				//gerando data do relat�rio
				$data=date('d/m/Y');
				$hora=date('H');
				$minutos=date('i');
				$segundos=date('s');
				echo '<center>';
				if($hora>=12 && $hora<18)
				{
				echo("Gerado em: $data - $hora:$minutos:$segundos");
				}
				if($hora>=18 && $hora<24)
				{
				echo("Gerado em: $data - $hora:$minutos:$segundos");
				}
				if($hora>=24 && $hora<12)
				{
				echo("Gerado em: $data - $hora:$minutos:$segundos");
				}
				echo '</center><br>';
		
		
		       //t�rmino data relat�rio

   echo'
    <table width="524" border="1">
      <tr>
        <td ><div align="center">';
		// exibe nome no in�cio da p�gina
		echo $nome;
		
		echo'</div>
		</td>
      </tr>
      <tr>
        <td>					
				 Rua: ';
			echo $rua;
			echo '<br>Numero: ';
			echo $numero;
			echo '<br>Complemento: ';	
			echo $complemento;
			echo '<br>Bairro: ';
			echo $bairro;
			echo '<br>Cidade: ';
			echo $cidade;
			echo '<br>UF: ';
			echo $uf;
			echo '<br>tel1: ';
			echo $tel1;
			echo '<br>Tel2: ';
			echo $tel2;
			echo '<br>SU: ';
			echo $su;		
		echo '
		</td>
      	</tr>
	</table>';
   } 
	else
	{	
		echo '<center> Usu�rio N�o Autorizado!';
	}

}
else
{
	echo '<center>Usuario n�o autorizado!';
}	
	
?>
</div>
</body>
</html>
