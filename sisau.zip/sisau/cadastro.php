<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
  	if ($logado == '2')
	{
	$id = $_SESSION['id'];
	//selecionando dados do usuario
	$result = mysql_query("SELECT * FROM cadastro WHERE id LIKE '%".$id."%';",$conexao);
	$Quantos = mysql_num_rows($result);
	if($Quantos > 0)
	{
	//iniciando vari�veis
	$resultnome = mysql_query("SELECT nome FROM usuarios WHERE id LIKE '%".$id."%';",$conexao);

	$nome = mysql_result($resultnome,0,nome);

	$rua = mysql_result($result,0,rua);
	$numero = mysql_result($result,0,numero);
	$complemento = mysql_result($result,0,complemento);
	$bairro = mysql_result($result,0,bairro);
	$cidade = mysql_result($result,0,cidade);
	$uf = mysql_result($result,0,uf);
	$tel1 = mysql_result($result,0,tel1);
	$tel2 = mysql_result($result,0,tel2);
	$su = mysql_result($result,0,su);

echo '

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title> Altualizar Cadastro</title>
</head>
<body>

<div align="center">
  <p>Dados do Endere�o Fixo Atual</p>
</div>
<form action="cadastro2.php" method="post" enctype="multipart/form-data" name="alterar">
  <div align="center">
    <table width="512" border="0">
	<tr>
        <td width="72">Nome:</td>
        <td width="430"><label>';
		
		echo '<input type="text" name="nome" size="60" value= "'.$nome.'">
		   	  <input type="hidden" name="nomeant" value= "'.$nome.'">';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="72">Rua:</td>
        <td width="430"><label>';
		
		echo '<input type="text" name="rua" size="60" value= "'.$rua.'">
		   	  <input type="hidden" name="ruaant" value= "'.$rua.'">';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="72">N�mero:</td>
        <td width="430"><label>';
		
		echo '<input type="text" name="numero" size="15" value= "'.$numero.'">
		   	  <input type="hidden" name="numeroant" value= "'.$numero.'">';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="72">Complemento:</td>
        <td width="430"><label>';
		
		echo '<input type="text" name="complemento" size="20" value= "'.$complemento.'">
		   	  <input type="hidden" name="complementoant" value= "'.$complemento.'">';
		echo '
        </label></td>
      </tr>
	    <tr>
        <td width="72">Bairro:</td>
        <td width="430"><label>';
		
		echo '<input type="text" name="bairro" size"40" value= "'.$bairro.'">
		   	  <input type="hidden" name="bairroant" value= "'.$bairro.'">';
		echo '
        </label></td>
      </tr>
	   <tr>
        <td width="72">Cidade:</td>
        <td width="430"><label>
		   <select name="cidade">';
		
         echo '<option value="'.$cidade.'">"'.$cidade.'"</option>';
		 echo '
		 	<option value="Itu">Itu</option>
            <option value="Salto">Salto</option>
			<option value="Indaiatuba">Indaiatuba</option>
            <option value="Sorocaba">Sorocaba</option>
			<option value="Cabreuva">Cabreuva</option>
			<option value="Itapetininga">Itapetininga</option>
            <option value="Itupeva">Itupeva</option>
            <option value="Porto Feliz">Porto Feliz</option>
			<option value="Jundia�">Jundia�</option>
			<option value="Boituva">Boituva</option>
          </select>
';
		echo '
        </label></td>
      </tr>
      <tr>
        <td>UF:</td>
        <td><label>
          <select name="uf">';
		
            echo '<option value="'.$uf.'">"'.$uf.'"</option>';
		 echo '
		 	<option value="AC">AC</option>
            <option value="AM">AM</option>
			<option value="AL">AL</option>
            <option value="AP">AP</option>
			<option value="BA">BA</option>
			<option value="CE">CE</option>
            <option value="DF">DF</option>
            <option value="ES">ES</option>
			<option value="GO">GO</option>
			<option value="MA">MA</option>
			<option value="MG">MG</option>
			<option value="MT">MT</option>
			<option value="MS">MS</option>
			<option value="PA">PA</option>
			<option value="PB">PB</option>
			<option value="PE">PE</option>
			<option value="PI">PI</option>
			<option value="PR">PR</option>
			<option value="RJ">RJ</option>
			<option value="RO">RO</option>
			<option value="RN">RN</option>
			<option value="RS">RS</option>
			<option value="SC">SC</option>
			<option value="SE">SE</option>
			<option value="SP">SP</option>
			<option value="TO">TO</option>
          </select>
        </label></td>
      </tr>
	  <tr>
        <td>SU:</td>
        <td><label>
        <select name="su">';
    echo '<option value="'.$su.'">"'.$su.'"</option>
          <option value="1bo">1� BO</option>
          <option value="2bo">2� BO</option>
          <option value="bc">BC</option>
          <option value="aae">AAe</option>
        </select>
        </label></td>
      </tr>

	    <tr>
        <td width="72">Tel 1:</td>
        <td width="430"><label>';
		
		echo '<input type="text" name="tel1" value= "'.$tel1.'"> Use formato 11-88887777
		   	  <input type="hidden" name="tel1ant" value= "'.$tel1.'">';
		echo '
        </label></td>
      </tr>
      <tr>
	  <tr>
        <td width="72">Tel 2:</td>
        <td width="430"><label>';
		
		echo '<input type="text" name="tel2" value= "'.$tel2.'"> Use formato 11-88887777
		   	  <input type="hidden" name="tel2ant" value= "'.$tel2.'">';
		echo '
        </label></td>
      </tr>
      <tr>
    </table>
    <p>
      <label>
      <input type="submit" name="Submit" value="Salvar">
      </label>
    </p>
  </div>
</form>
<p align="center">&nbsp;</p>
</body>
</html>';
}
else
{
	echo '<center> Usu�rio n�o encontrado!<br> <a href="alterarmatricula.html" target="Display">Voltar</a>';
}
}
	else
		{
			echo '<center>Usuario n�o autorizado!';
		}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>
