<?
include "base.php";
session_start("usuarios");
$logado = $_SESSION['nivel'];
if ($logado == '1')
		{
		echo'
		<htm>
<head>
<title>Altera Senha</title>
</head>
<body>
	<div align="center">
  <p>Alterar Senha</p>
</div>
<div align="center">
  <form action="alterasenha2.php" method="post" name="form1" target="Display" id="form1">
    <label for="textfield">
    <div align="center"></div>
    </label>
    <p align="center">Senha Atual: 
      <input type="password" name="atual" id="descricao" />
    </p>
	<p align="center">Nova Senha: 
      <input type="password" name="nova" id="descricao" />
    </p>
	<p align="center">Confirmar Senha: 
      <input type="password" name="confirma" id="descricao" />
    </p>
    <p>
      <label for="Submit"></label>
      <input type="submit" name="Submit" value="Alterar" id="Submit" />
    </p>
  </form>

</body>
</html>';

		}
	else
	{echo '
	<htm>
<head>
<title>Alterar Senha</title>
</head>
<body>
	<center>Usuario n�o autorizado!
	
	</body>
</html>';

	}
	?>