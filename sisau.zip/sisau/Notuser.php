<?
	echo '<span style="font-size:12.0pt; font-family:Verdana; color:#000080">';
	echo '<p align="center">';
	echo 'Voce deve se logar para ter acesso ao conteudo da p�gina!</p>';
?>