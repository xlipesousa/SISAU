<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
	$id = $_SESSION['id'];
  	if ($logado == '1')
	{		
		echo'<html>
		<head>
		<title>Relat�rio</title>
		</head>
		<body>';
				
		//formatando data
		$datasaida = "".$HTTP_POST_VARS['anosaida']."-".$_POST['messaida']."-".$_POST['diasaida']."";
		$dataretorno = "".$HTTP_POST_VARS['anoretorno']."-".$_POST['mesretorno']."-".$_POST['diaretorno']."";
		//inserindo no banco		
		$result = mysql_query("SELECT * FROM destino WHERE datasaida BETWEEN '".$datasaida."' AND '".$dataretorno."' order by datasaida desc;",$conexao);
       
		$Quantos = mysql_num_rows($result);
		if($Quantos > 0)
			{
				// formatando cabe�alho com data
				$diasaida = $HTTP_POST_VARS['diasaida'];
				$messaida = $HTTP_POST_VARS['messaida'];
				$anosaida = $HTTP_POST_VARS['anosaida'];
				$diaretorno = $HTTP_POST_VARS['diaretorno'];
				$mesretorno = $HTTP_POST_VARS['mesretorno'];
				$anoretorno = $HTTP_POST_VARS['anoretorno'];
				
				//cabe�alho
				
        echo' <center>Militares que se Ausentar�o da Guarni��o no Per�odo de: <br><center>';
		echo $diasaida;
		echo '/';
		echo $messaida;
		echo'/';
		echo $anosaida;
		echo' a ';
		echo $diaretorno;
		echo '/';
		echo $mesretorno;
		echo'/';
		echo $anoretorno;
		
		echo '<br><br><center>Total de registros encontrados: ';
		echo $Quantos;		
				
				//formatando a tabela de destinos
				echo'
    <table width="524" border="1">
      
      <tr>
        <td width="200"><div align="center">Nome</div></td>
        <td width="118"><div align="center">Cidade</div></td>
		<td width="8"><div align="center">UF</div></td>
        <td width="70"><div align="center">Partida</div></td>
        <td width="7"><div align="center">Retorno</div></td>
        <td width="58"><div align="center">Detalhes</div></td>
      </tr>
      <tr>';
//preenchendo a tabela	  
		$i=0;
			for ($i==0; $i<$Quantos; $i++)
						{
							$cidade = mysql_result($result,$i,cidade);
							$uf = mysql_result($result,$i,uf);
							$diasaida1 = mysql_result($result,$i,diasaida);
							$messaida1 = mysql_result($result,$i,messaida);
							$anosaida1 = mysql_result($result,$i,anosaida);
							$diaretorno1 = mysql_result($result,$i,diaretorno);
							$mesretorno1 = mysql_result($result,$i,mesretorno);
							$anoretorno1 = mysql_result($result,$i,anoretorno);
							$id = mysql_result($result,$i,id);
							echo '<td>';
							$consulta = mysql_query("SELECT nome FROM usuarios WHERE id like '".$id."';",$conexao);
							$nome = mysql_result($consulta,0,nome);
							echo $nome;
							echo'</td>';
							echo '<td>';
							echo $cidade;
							echo'</td>';
							echo '<td>';
							echo $uf;
							echo'</td>';
							echo '<td>';
							echo $diasaida1;
							echo '/';
							echo $messaida1;
							echo '/';
							echo $anosaida1;
							echo'</td>';
							echo '<td>';
							echo $diaretorno1;
							echo '/';
							echo $mesretorno1;
							echo '/';
							echo $anoretorno1;
							echo'</td>';
							///link para visualizar o pedido
							echo '<td><center>';
							echo '<form action="relatorio3.php" method="post" name="form1" target="Display">';
    						echo'<input name="id" type="hidden" id="id" size="7" maxlength="20" value= "'.$id.'">';
    						echo'<input name="nome" type="hidden" id="id" size="7" maxlength="20" value= "'.$nome.'">';
							echo'<input type="submit" name="Submit" value="Ver">
								 </form>';
							echo '</td></tr>';
						}
			
			echo '</table>';
			//bot�es de impress�o
			
			echo'<br><br><center> Vers�es Para Impress�o<br><br>';
			echo '<form action="imprimirresumido.php" method="post" name="form1" target="_blanck">';
    						echo'<input name="diasaida" type="hidden" id="id" size="7" maxlength="20" value= "'.$diasaida.'">';
    						echo'<input name="messaida" type="hidden" id="id" size="7" maxlength="20" value= "'.$messaida.'">';
    						echo'<input name="anosaida" type="hidden" id="id" size="7" maxlength="20" value= "'.$anosaida.'">';
    						echo'<input name="diaretorno" type="hidden" id="id" size="7" maxlength="20" value= "'.$diaretorno.'">';
    						echo'<input name="mesretorno" type="hidden" id="id" size="7" maxlength="20" value= "'.$mesretorno.'">';
    						echo'<input name="anoretorno" type="hidden" id="id" size="7" maxlength="20" value= "'.$anoretorno.'">';
							echo'<input type="submit" name="Submit" value="Resumido">
								 </form>';
			echo '<form action="imprimircompleto.php" method="post" name="form1" target="_blanck">';
    						echo'<input name="diasaida" type="hidden" id="id" size="7" maxlength="20" value= "'.$diasaida.'">';
    						echo'<input name="messaida" type="hidden" id="id" size="7" maxlength="20" value= "'.$messaida.'">';
    						echo'<input name="anosaida" type="hidden" id="id" size="7" maxlength="20" value= "'.$anosaida.'">';
    						echo'<input name="diaretorno" type="hidden" id="id" size="7" maxlength="20" value= "'.$diaretorno.'">';
    						echo'<input name="mesretorno" type="hidden" id="id" size="7" maxlength="20" value= "'.$mesretorno.'">';
    						echo'<input name="anoretorno" type="hidden" id="id" size="7" maxlength="20" value= "'.$anoretorno.'">';
							echo'<input type="submit" name="Submit" value="Completo">
								 </form>';

			}

				//fim da tabela de destinos
		else
			{
				echo '<center>Nenhum registro encontrado para este per�odo.';
			}
	
	}
	else
	{
		echo '<center>Usuario n�o autorizado!';
	}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>
</body>
</html>
